package net.johnpwood.android.standuptimer.dao;

public interface DatabaseConstants {
    public static final String DATABASE_NAME = "standup_timer.db";
    public static final int DATABASE_VERSION = 1;
}
