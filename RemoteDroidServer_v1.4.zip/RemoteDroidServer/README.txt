Windows
-------
Double-click RemoteDroidServer.jar to start the server application.

OSX, Linux
----------
Double-click RemoteDroidServer.jar to start the server application.



The Java SE runtime environment is needed to use this program.

Mac and Windows users can go to

http://www.java.com/en/download/manual.jsp

to download the runtime environment.